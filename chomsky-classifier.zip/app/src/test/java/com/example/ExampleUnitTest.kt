package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCase1_Type3() {
        val valRes = ChomskyClassifierEngine.validateGrammar(
            nonTerminalsInput = "S, A",
            terminalsInput = "a, b",
            startSymbolInput = "S",
            productionsInput = "S -> aA\nA -> b"
        )
        assertTrue(valRes.isValid)
        val res = ChomskyClassifierEngine.classifyGrammar(
            valRes.nonTerminals,
            valRes.terminals,
            valRes.startSymbol,
            valRes.productions
        )
        assertEquals("Type 3", res.type)
        assertEquals("Regular Grammar", res.name)
        assertTrue(res.checks.first().passed)
    }

    @Test
    fun testCase2_Type2() {
        val valRes = ChomskyClassifierEngine.validateGrammar(
            nonTerminalsInput = "S, A, B",
            terminalsInput = "a, b",
            startSymbolInput = "S",
            productionsInput = "S -> AB\nA -> a\nB -> b"
        )
        assertTrue(valRes.isValid)
        val res = ChomskyClassifierEngine.classifyGrammar(
            valRes.nonTerminals,
            valRes.terminals,
            valRes.startSymbol,
            valRes.productions
        )
        assertEquals("Type 2", res.type)
        assertEquals("Context-Free Grammar", res.name)
        assertFalse(res.checks[0].passed) // Type 3 failed (S -> AB)
        assertTrue(res.checks[1].passed)  // Type 2 passed
    }

    @Test
    fun testCase3_Type1() {
        val valRes = ChomskyClassifierEngine.validateGrammar(
            nonTerminalsInput = "S, A, B, C",
            terminalsInput = "a, b, c",
            startSymbolInput = "S",
            productionsInput = "S -> aABC\naA -> aB\nB -> b\nBC -> bc\nC -> c"
        )
        assertTrue(valRes.isValid)
        val res = ChomskyClassifierEngine.classifyGrammar(
            valRes.nonTerminals,
            valRes.terminals,
            valRes.startSymbol,
            valRes.productions
        )
        assertEquals("Type 1", res.type)
        assertEquals("Context-Sensitive Grammar", res.name)
        assertFalse(res.checks[0].passed) // Type 3 failed
        assertFalse(res.checks[1].passed) // Type 2 failed (|aA| = 2)
        assertTrue(res.checks[2].passed)  // Type 1 passed
    }

    @Test
    fun testCase4_Type0() {
        val valRes = ChomskyClassifierEngine.validateGrammar(
            nonTerminalsInput = "S, A, B",
            terminalsInput = "a, b",
            startSymbolInput = "S",
            productionsInput = "S -> AB\nAB -> a\nA -> a\nB -> b"
        )
        assertTrue(valRes.isValid)
        val res = ChomskyClassifierEngine.classifyGrammar(
            valRes.nonTerminals,
            valRes.terminals,
            valRes.startSymbol,
            valRes.productions
        )
        assertEquals("Type 0", res.type)
        assertEquals("Unrestricted Grammar", res.name)
        assertFalse(res.checks[0].passed)
        assertFalse(res.checks[1].passed)
        assertFalse(res.checks[2].passed) // AB -> a contracts (2 > 1)
    }

    @Test
    fun testMixedLinear_Type2() {
        // Mixed right and left linear: S -> aA (right), A -> Ba (left)
        val valRes = ChomskyClassifierEngine.validateGrammar(
            nonTerminalsInput = "S, A, B",
            terminalsInput = "a, b",
            startSymbolInput = "S",
            productionsInput = "S -> aA\nA -> Ba\nB -> b"
        )
        assertTrue(valRes.isValid)
        val res = ChomskyClassifierEngine.classifyGrammar(
            valRes.nonTerminals,
            valRes.terminals,
            valRes.startSymbol,
            valRes.productions
        )
        assertEquals("Type 2", res.type)
    }
}
