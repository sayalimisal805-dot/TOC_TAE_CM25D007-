package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
        ) { innerPadding ->
          ChomskyClassifierApp(modifier = Modifier.padding(innerPadding))
        }
      }
    }
  }
}

@Composable
fun ChomskyClassifierApp(modifier: Modifier = Modifier) {
  var nonTerminalsText by remember { mutableStateOf("S, A, B") }
  var terminalsText by remember { mutableStateOf("a, b") }
  var startSymbolText by remember { mutableStateOf("S") }
  var productionsText by remember { mutableStateOf("S -> AB\nA -> a\nB -> b") }

  var validationError by remember { mutableStateOf<String?>(null) }
  var errorTitle by remember { mutableStateOf("Invalid Grammar") }
  var classificationResult by remember { mutableStateOf<ClassificationResult?>(null) }

  val scrollState = rememberScrollState()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFFF8FAFC)),
    contentAlignment = Alignment.TopCenter
  ) {
    Column(
      modifier = Modifier
        .widthIn(max = 680.dp)
        .fillMaxWidth()
        .verticalScroll(scrollState)
        .padding(horizontal = 16.dp, vertical = 20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Project Title & 2. Short Instruction
      Column {
        Text(
          text = "Chomsky Classifier Pipeline",
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF0F172A),
          letterSpacing = (-0.5).sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Enter a formal grammar and classify it according to the Chomsky hierarchy.",
          fontSize = 14.sp,
          color = Color(0xFF64748B),
          lineHeight = 20.sp
        )
      }

      // Error message card if validation fails
      if (validationError != null) {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("error_card"),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
          shape = RoundedCornerShape(12.dp),
          border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFF87171)))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = errorTitle,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF991B1B)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = validationError ?: "",
              fontSize = 14.sp,
              color = Color(0xFFB91C1C),
              lineHeight = 20.sp
            )
          }
        }
      }

      // Input Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Non-terminals
          Column {
            Text(
              text = "Non-terminals",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = nonTerminalsText,
              onValueChange = { nonTerminalsText = it },
              placeholder = { Text("e.g. S, A, B", color = Color(0xFF94A3B8)) },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("non_terminals_input"),
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF2563EB),
                unfocusedBorderColor = Color(0xFFCBD5E1)
              )
            )
          }

          // Terminals
          Column {
            Text(
              text = "Terminals",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = terminalsText,
              onValueChange = { terminalsText = it },
              placeholder = { Text("e.g. a, b", color = Color(0xFF94A3B8)) },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("terminals_input"),
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF2563EB),
                unfocusedBorderColor = Color(0xFFCBD5E1)
              )
            )
          }

          // Start Symbol
          Column {
            Text(
              text = "Start Symbol",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = startSymbolText,
              onValueChange = { startSymbolText = it },
              placeholder = { Text("e.g. S", color = Color(0xFF94A3B8)) },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("start_symbol_input"),
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF2563EB),
                unfocusedBorderColor = Color(0xFFCBD5E1)
              )
            )
          }

          // Production Rules
          Column {
            Text(
              text = "Production Rules",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
              value = productionsText,
              onValueChange = { productionsText = it },
              placeholder = {
                Text(
                  "S -> AB\nA -> a\nB -> b",
                  color = Color(0xFF94A3B8),
                  fontFamily = FontFamily.Monospace
                )
              },
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp)
                .testTag("production_rules_input"),
              textStyle = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                color = Color(0xFF0F172A),
                lineHeight = 20.sp
              ),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF2563EB),
                unfocusedBorderColor = Color(0xFFCBD5E1)
              )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "One rule per line. Use -> or → (use ε, epsilon, or ^ for empty string)",
              fontSize = 12.sp,
              color = Color(0xFF94A3B8)
            )
          }

          // Button Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = {
                val validation = ChomskyClassifierEngine.validateGrammar(
                  nonTerminalsInput = nonTerminalsText,
                  terminalsInput = terminalsText,
                  startSymbolInput = startSymbolText,
                  productionsInput = productionsText
                )

                if (!validation.isValid) {
                  errorTitle = validation.errorTitle
                  validationError = validation.errorMessage
                  classificationResult = null
                } else {
                  validationError = null
                  classificationResult = ChomskyClassifierEngine.classifyGrammar(
                    nonTerminals = validation.nonTerminals,
                    terminals = validation.terminals,
                    startSymbol = validation.startSymbol,
                    productions = validation.productions
                  )
                }
              },
              modifier = Modifier
                .weight(1.3f)
                .height(48.dp)
                .testTag("classify_button"),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
              Text(
                text = "Classify Grammar",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
              )
            }

            OutlinedButton(
              onClick = {
                nonTerminalsText = ""
                terminalsText = ""
                startSymbolText = ""
                productionsText = ""
                validationError = null
                classificationResult = null
              },
              modifier = Modifier
                .weight(0.7f)
                .height(48.dp)
                .testTag("clear_button"),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF475569))
            ) {
              Text(
                text = "Clear",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }
      }

      // 5. Result Section
      classificationResult?.let { res ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("result_card"),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          shape = RoundedCornerShape(14.dp),
          border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFE2E8F0))),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            // Classification block
            Column {
              Text(
                text = "Grammar Classification",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFEFF6FF),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "Type: ",
                      fontSize = 15.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = Color(0xFF1E40AF)
                    )
                    Text(
                      text = res.type,
                      fontSize = 16.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF1D4ED8)
                    )
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "Name: ",
                      fontSize = 15.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = Color(0xFF1E40AF)
                    )
                    Text(
                      text = res.name,
                      fontSize = 16.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFF1D4ED8)
                    )
                  }
                }
              }
            }

            HorizontalDivider(color = Color(0xFFE2E8F0))

            // Structural Analysis block
            Column {
              Text(
                text = "Structural Analysis",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF8FAFC),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  res.checks.forEachIndexed { idx, check ->
                    if (idx > 0) {
                      HorizontalDivider(
                        color = Color(0xFFE2E8F0),
                        modifier = Modifier.padding(vertical = 8.dp)
                      )
                    }
                    Column {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                          imageVector = if (check.passed) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                          contentDescription = if (check.passed) "Passed" else "Failed",
                          tint = if (check.passed) Color(0xFF16A34A) else Color(0xFFDC2626),
                          modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = check.label + if (check.passed) " (Passed)" else " (Failed)",
                          fontSize = 14.sp,
                          fontWeight = FontWeight.Bold,
                          color = if (check.passed) Color(0xFF16A34A) else Color(0xFFDC2626)
                        )
                      }
                      if (check.reason.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                          text = check.reason,
                          fontSize = 13.sp,
                          color = Color(0xFF475569),
                          modifier = Modifier.padding(start = 24.dp),
                          lineHeight = 18.sp
                        )
                      }
                    }
                  }
                }
              }
            }

            HorizontalDivider(color = Color(0xFFE2E8F0))

            // Reason block
            Column {
              Text(
                text = "Reason",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF8FAFC),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
              ) {
                Text(
                  text = res.reason,
                  fontSize = 14.sp,
                  color = Color(0xFF334155),
                  lineHeight = 20.sp,
                  modifier = Modifier.padding(14.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}
