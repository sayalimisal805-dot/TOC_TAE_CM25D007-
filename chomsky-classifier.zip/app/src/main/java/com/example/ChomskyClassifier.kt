package com.example

data class ProductionRule(
    val raw: String,
    val rawLhs: String,
    val rawRhs: String,
    val lhsTokens: List<String>,
    val rhsTokens: List<String>,
    val isEpsilon: Boolean
)

data class ValidationResult(
    val isValid: Boolean,
    val errorTitle: String = "",
    val errorMessage: String = "",
    val nonTerminals: List<String> = emptyList(),
    val terminals: List<String> = emptyList(),
    val startSymbol: String = "",
    val productions: List<ProductionRule> = emptyList()
)

data class StructuralCheck(
    val label: String,
    val passed: Boolean,
    val reason: String
)

data class ClassificationResult(
    val type: String,
    val name: String,
    val checks: List<StructuralCheck>,
    val reason: String
)

object ChomskyClassifierEngine {

    fun parseSymbolList(input: String): List<String> {
        return input.split(Regex("[\\s,]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
    }

    fun isEpsilonToken(token: String): Boolean {
        val lower = token.trim().lowercase()
        return lower in listOf("ε", "epsilon", "^", "λ", "e", "")
    }

    data class TokenizeResult(
        val tokens: List<String>,
        val isValid: Boolean,
        val errorMessage: String? = null
    )

    fun tokenizeString(input: String, validSymbols: List<String>): TokenizeResult {
        val trimmed = input.trim()
        if (trimmed.isEmpty() || isEpsilonToken(trimmed)) {
            return TokenizeResult(emptyList(), true)
        }

        // Sort descending by length for greedy longest prefix matching
        val sortedSymbols = validSymbols.sortedByDescending { it.length }
        val tokens = mutableListOf<String>()
        var i = 0

        while (i < trimmed.length) {
            if (trimmed[i].isWhitespace()) {
                i++
                continue
            }

            var matched = false
            for (sym in sortedSymbols) {
                if (trimmed.startsWith(sym, i)) {
                    tokens.add(sym)
                    i += sym.length
                    matched = true
                    break
                }
            }

            if (!matched) {
                val preview = trimmed.substring(i, (i + 3).coerceAtMost(trimmed.length))
                return TokenizeResult(
                    tokens = emptyList(),
                    isValid = false,
                    errorMessage = "Undefined symbol starting at '$preview'"
                )
            }
        }

        return TokenizeResult(tokens, true)
    }

    // 1. validateGrammar()
    fun validateGrammar(
        nonTerminalsInput: String,
        terminalsInput: String,
        startSymbolInput: String,
        productionsInput: String
    ): ValidationResult {
        val nonTerminals = parseSymbolList(nonTerminalsInput)
        val terminals = parseSymbolList(terminalsInput)
        val startSymbol = startSymbolInput.trim()

        if (nonTerminals.isEmpty()) {
            return ValidationResult(
                isValid = false,
                errorTitle = "Invalid Grammar",
                errorMessage = "Non-terminals cannot be empty. Please enter at least one non-terminal variable."
            )
        }

        if (terminals.isEmpty()) {
            return ValidationResult(
                isValid = false,
                errorTitle = "Invalid Grammar",
                errorMessage = "Terminals cannot be empty. Please enter at least one terminal symbol."
            )
        }

        val nonTerminalSet = nonTerminals.toSet()
        for (t in terminals) {
            if (nonTerminalSet.contains(t)) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Symbol '$t' cannot be both a non-terminal and a terminal."
                )
            }
        }

        if (startSymbol.isEmpty()) {
            return ValidationResult(
                isValid = false,
                errorTitle = "Invalid Grammar",
                errorMessage = "Missing start symbol. Please specify a start symbol."
            )
        }

        if (!nonTerminalSet.contains(startSymbol)) {
            return ValidationResult(
                isValid = false,
                errorTitle = "Invalid Grammar",
                errorMessage = "Start symbol '$startSymbol' must be one of the declared non-terminals (${nonTerminals.joinToString(", ")})."
            )
        }

        if (productionsInput.trim().isEmpty()) {
            return ValidationResult(
                isValid = false,
                errorTitle = "Invalid Grammar",
                errorMessage = "Missing production rule. Please enter valid production rules.\n\nExample:\nS -> AB\nA -> a\nB -> b"
            )
        }

        val allSymbols = nonTerminals + terminals
        val lines = productionsInput.split("\n")
        val parsedProductions = mutableListOf<ProductionRule>()

        for ((index, rawLine) in lines.withIndex()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            val arrowMatch = Regex("->|-->|→").find(line)
            if (arrowMatch == null) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Invalid production syntax on line ${index + 1}: '$line'.\nRules must use '->' or '→'.\n\nExample:\nS -> AB\nA -> a\nB -> b"
                )
            }

            val parts = line.split(Regex("->|-->|→"))
            if (parts.size != 2) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Invalid production syntax on line ${index + 1}: '$line'. Contains multiple arrow operators."
                )
            }

            val rawLhs = parts[0].trim()
            val rawRhs = parts[1].trim()

            if (rawLhs.isEmpty()) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Production without a left-hand side on line ${index + 1}: '$line'."
                )
            }

            if (isEpsilonToken(rawLhs)) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Invalid use of epsilon on line ${index + 1}: Epsilon cannot appear on the left-hand side of a production rule."
                )
            }

            val lhsRes = tokenizeString(rawLhs, allSymbols)
            if (!lhsRes.isValid || lhsRes.tokens.isEmpty()) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Undefined symbols in left-hand side of rule: '$line'. Please check declared non-terminals and terminals."
                )
            }

            val hasNtInLhs = lhsRes.tokens.any { nonTerminalSet.contains(it) }
            if (!hasNtInLhs) {
                return ValidationResult(
                    isValid = false,
                    errorTitle = "Invalid Grammar",
                    errorMessage = "Invalid production rule: '$line'. Left-hand side must contain at least one non-terminal variable."
                )
            }

            val isRhsEpsilon = isEpsilonToken(rawRhs)
            val rhsTokens = if (!isRhsEpsilon) {
                val rhsRes = tokenizeString(rawRhs, allSymbols)
                if (!rhsRes.isValid) {
                    return ValidationResult(
                        isValid = false,
                        errorTitle = "Invalid Grammar",
                        errorMessage = "Undefined symbols in right-hand side of rule: '$line'. Please check declared non-terminals and terminals."
                    )
                }
                rhsRes.tokens
            } else {
                emptyList()
            }

            parsedProductions.add(
                ProductionRule(
                    raw = line,
                    rawLhs = rawLhs,
                    rawRhs = rawRhs,
                    lhsTokens = lhsRes.tokens,
                    rhsTokens = rhsTokens,
                    isEpsilon = isRhsEpsilon
                )
            )
        }

        if (parsedProductions.isEmpty()) {
            return ValidationResult(
                isValid = false,
                errorTitle = "Invalid Grammar",
                errorMessage = "Missing production rule. Please enter valid production rules.\n\nExample:\nS -> AB\nA -> a\nB -> b"
            )
        }

        return ValidationResult(
            isValid = true,
            nonTerminals = nonTerminals,
            terminals = terminals,
            startSymbol = startSymbol,
            productions = parsedProductions
        )
    }

    // 2. isType3() — Regular Grammar
    fun isType3(
        productions: List<ProductionRule>,
        nonTerminals: List<String>,
        terminals: List<String>,
        startSymbol: String
    ): StructuralCheck {
        val ntSet = nonTerminals.toSet()
        var seenRightLinear = false
        var seenLeftLinear = false
        var rightLinearExample = ""
        var leftLinearExample = ""

        for (prod in productions) {
            if (prod.lhsTokens.size != 1 || !ntSet.contains(prod.lhsTokens[0])) {
                return StructuralCheck(
                    label = "Type 3 Check",
                    passed = false,
                    reason = "Production '${prod.raw}' has left-hand side with length ${prod.lhsTokens.size} (${prod.rawLhs}), but Type 3 requires exactly one non-terminal on the left-hand side."
                )
            }

            if (prod.isEpsilon || prod.rhsTokens.isEmpty()) {
                continue
            }

            val ntIndices = prod.rhsTokens.mapIndexedNotNull { i, tok ->
                if (ntSet.contains(tok)) i else null
            }

            if (ntIndices.size > 1) {
                val ntList = ntIndices.map { prod.rhsTokens[it] }.joinToString(", ")
                return StructuralCheck(
                    label = "Type 3 Check",
                    passed = false,
                    reason = "Production ${prod.raw} contains more than one non-terminal on the right-hand side ($ntList). Type 3 allows at most one non-terminal on the right-hand side."
                )
            }

            if (ntIndices.size == 1) {
                val ntPos = ntIndices[0]
                val isRight = (ntPos == prod.rhsTokens.size - 1)
                val isLeft = (ntPos == 0)

                if (isRight) {
                    seenRightLinear = true
                    rightLinearExample = prod.raw
                } else if (isLeft) {
                    seenLeftLinear = true
                    leftLinearExample = prod.raw
                } else {
                    return StructuralCheck(
                        label = "Type 3 Check",
                        passed = false,
                        reason = "Production ${prod.raw} contains non-terminal '${prod.rhsTokens[ntPos]}' in the middle of terminals, violating both left-linear and right-linear forms."
                    )
                }
            }
        }

        if (seenRightLinear && seenLeftLinear) {
            return StructuralCheck(
                label = "Type 3 Check",
                passed = false,
                reason = "Grammar mixes right-linear productions (e.g., '$rightLinearExample') and left-linear productions (e.g., '$leftLinearExample'). A regular grammar must be purely right-linear or purely left-linear."
            )
        }

        val form = if (seenLeftLinear) "Left-Linear" else "Right-Linear"
        return StructuralCheck(
            label = "Type 3 Check",
            passed = true,
            reason = "All production rules satisfy the structural restrictions of a regular grammar ($form form)."
        )
    }

    // 3. isType2() — Context-Free Grammar
    fun isType2(
        productions: List<ProductionRule>,
        nonTerminals: List<String>,
        terminals: List<String>
    ): StructuralCheck {
        val ntSet = nonTerminals.toSet()

        for (prod in productions) {
            if (prod.lhsTokens.size != 1 || !ntSet.contains(prod.lhsTokens[0])) {
                return StructuralCheck(
                    label = "Type 2 Check",
                    passed = false,
                    reason = "Production '${prod.raw}' has left-hand side '${prod.rawLhs}' of length ${prod.lhsTokens.size}, but Type 2 requires exactly one non-terminal on the left-hand side."
                )
            }
        }

        return StructuralCheck(
            label = "Type 2 Check",
            passed = true,
            reason = "All production rules have exactly one non-terminal on the left-hand side."
        )
    }

    // 4. isType1() — Context-Sensitive Grammar
    fun isType1(
        productions: List<ProductionRule>,
        nonTerminals: List<String>,
        terminals: List<String>,
        startSymbol: String
    ): StructuralCheck {
        var hasStartSymbolEpsilon = false

        for (prod in productions) {
            if (prod.isEpsilon || prod.rhsTokens.isEmpty()) {
                if (prod.lhsTokens.size == 1 && prod.lhsTokens[0] == startSymbol) {
                    hasStartSymbolEpsilon = true
                } else {
                    return StructuralCheck(
                        label = "Type 1 Check",
                        passed = false,
                        reason = "Production '${prod.raw}' derives epsilon, but only the start symbol '$startSymbol' can derive epsilon in a Type 1 grammar."
                    )
                }
            }
        }

        if (hasStartSymbolEpsilon) {
            for (prod in productions) {
                if (prod.rhsTokens.contains(startSymbol)) {
                    return StructuralCheck(
                        label = "Type 1 Check",
                        passed = false,
                        reason = "Start symbol derivation '$startSymbol -> ε' is present, but start symbol '$startSymbol' appears on the right-hand side of production '${prod.raw}', violating the Type 1 non-contracting epsilon condition."
                    )
                }
            }
        }

        for (prod in productions) {
            if (prod.isEpsilon || prod.rhsTokens.isEmpty()) {
                continue
            }

            if (prod.lhsTokens.size > prod.rhsTokens.size) {
                return StructuralCheck(
                    label = "Type 1 Check",
                    passed = false,
                    reason = "Production '${prod.raw}' contracts: length of LHS (${prod.lhsTokens.size}) is greater than length of RHS (${prod.rhsTokens.size}), violating the non-contracting condition |LHS| <= |RHS|."
                )
            }
        }

        return StructuralCheck(
            label = "Type 1 Check",
            passed = true,
            reason = "All production rules satisfy the non-contracting condition (|LHS| <= |RHS|)" +
                if (hasStartSymbolEpsilon) " with valid start symbol epsilon derivation." else "."
        )
    }

    // 5. classifyGrammar()
    fun classifyGrammar(
        nonTerminals: List<String>,
        terminals: List<String>,
        startSymbol: String,
        productions: List<ProductionRule>
    ): ClassificationResult {
        val type3Res = isType3(productions, nonTerminals, terminals, startSymbol)
        val type2Res = isType2(productions, nonTerminals, terminals)
        val type1Res = isType1(productions, nonTerminals, terminals, startSymbol)

        val checks = mutableListOf<StructuralCheck>()

        // Hierarchy: Type 3 -> Type 2 -> Type 1 -> Type 0
        if (type3Res.passed) {
            checks.add(type3Res)
            return ClassificationResult(
                type = "Type 3",
                name = "Regular Grammar",
                checks = checks,
                reason = "All production rules satisfy the structural restrictions of a regular grammar. Every rule has a single non-terminal on the left-hand side, and right-hand sides strictly follow a single linear pattern."
            )
        }

        checks.add(type3Res)

        if (type2Res.passed) {
            checks.add(type2Res)
            return ClassificationResult(
                type = "Type 2",
                name = "Context-Free Grammar",
                checks = checks,
                reason = "All production rules have exactly one non-terminal on the left-hand side (A -> α), but the grammar fails Type 3 regular grammar restrictions."
            )
        }

        checks.add(type2Res)

        if (type1Res.passed) {
            checks.add(type1Res)
            return ClassificationResult(
                type = "Type 1",
                name = "Context-Sensitive Grammar",
                checks = checks,
                reason = "All production rules satisfy the non-contracting condition (|LHS| <= |RHS|), but the grammar contains productions with multiple symbols on the left-hand side."
            )
        }

        checks.add(type1Res)

        return ClassificationResult(
            type = "Type 0",
            name = "Unrestricted Grammar",
            checks = checks,
            reason = "The grammar does not satisfy Type 1 structural restrictions because of contracting production rules (|LHS| > |RHS|) or invalid epsilon derivations, classifying it as Type 0."
        )
    }
}
